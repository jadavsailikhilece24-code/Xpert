# Cold Start Solution Write-up

## 1. Architecture & Strategy

The solution processes raw export dumps (`chats.jsonl`, `messages.jsonl`, `seed.json`) into the official `schema.json` specification through a sequential, modular pipeline with clear separation of deterministic logic and LLM reasoning:

1. **Ingestion & Preprocessing (`preprocessing.py`, `seed.py`, `context.py`)**: Auto-detects field names across schema variations without hardcoding key names. Chronologically sorts messages, filters noise (system/media placeholders), indexes messages and chats in memory, and builds identity context (resolving "ME" and participant labels).
2. **Seed Grounding (`seed.py`)**: Preserves declared signup information (circles, organisations, goals) with immutable priority.
3. **Entity Extraction (`people_analyzer.py`, `organisation_analyzer.py`)**: Classifies relationship circles for unseeded contacts via batched LLM calls. Discovers organisations (companies, home, housing societies, schools) from conversation themes and participant clustering, defaulting home residence to role `owner` and type `residence`.
4. **Chat Ownership (`chat_classifier.py`)**: Maps 1:1 chats deterministically to their sole counterpart; groups are classified to organisations or primary persons based on topic context and participant overlap.
5. **Goal Discovery (`goal_extractor.py`)**: Filters Arjun's longer forward-looking messages (`>= 25` characters) across rolling windows, then merges and deduplicates candidates into at most 10 well-evidenced goals with verified message IDs.
6. **Open-Loop Lifecycle**:
   - **Detection (`open_loop_detector.py`)**: Discovers actionable asks, commitments, deadlines, and questions across batched chat windows.
   - **Resolution Tracking (`loop_tracker.py`)**: Clusters loops chronologically per chat and replays subsequent messages to detect verified completions or cancellations.
   - **Assistance Decision (`assistance_decider.py`)**: Decides whether Arjun's assistant should `assist` (actionable research/drafts), `remind` (scheduled before due dates), or `leave` (non-Arjun tasks, personal/sensitive topics).
7. **Validation & Assembly (`validator.py`, `output_builder.py`)**: Strictly enforces schema constraints, referential integrity, allowed enum values, ISO timestamps, and required non-null fields before emitting the final JSON.

## 2. LLM Pipeline, Concurrency & Cost Efficiency

- **OpenAI-Compatible Engine (`llm_client.py`)**: Operates against any OpenAI-compatible endpoint using `LLM_BASE_URL`, `LLM_API_KEY`, and `LLM_MODEL`. Standard library only (`urllib`), requiring zero external dependencies.
- **Robustness & Error Recovery**: Features exponential backoff, client-side rate limiting (`XPERT_MAX_RPM`), dynamic 429 cooldowns honoring `Retry-After` headers, and structured JSON parsing with automatic repair passes.
- **Resilient Fallback**: If an API provider quota is exhausted or times out, the pipeline seamlessly degrades to an offline multilingual rule-based responder (`heuristic_llm.py`), ensuring complete pipeline execution without crashing or creating schema violations. Fallback outputs are not cached to disk, preserving instant resumability once API quotas reset.
- **Caching & Time Guard**: Deterministic SHA-256 disk caching (`.cache/`) avoids redundant API spend across runs. A 26-minute wall-clock watchdog safely winds down model calls to guarantee submission output before the official 30-minute limit.
- **Cost Minimization**: Uses token-packed windowing (`XPERT_LEAN=1`), filters team operational chatter, and limits LLM calls to semantic tasks. Dev set volume is ~250k input tokens (~55k tokens per 1,000 messages), costing a few cents on modern flash-class models.

## 3. Multilingual Handling & Open-Loop Tracking

- **Multilingual Recognition**: Prompts and heuristic rules explicitly handle mixed English, Hindi, Bengali, and Hinglish. Key patterns include Indian informal requests (*"pls pay 2800"*, *"car at 4?"*, *"bhej do"*, *"kar do"*), commitments (*"kar dunga"*, *"kal bhejta hu"*, *"পাঠিয়ে দেব"*), and resolutions (*"done"*, *"paid"*, *"bhej diya"*, *"mil gaya"*, *"ho gaya"*, *"payment done"*).
- **Attribution & Noise Filtering**: Personal commitments and direct requests to Arjun become his obligations. Routine operational tickets in large group chats (>5 members) are filtered out unless Arjun explicitly volunteers.
- **Positional Clustering**: In long threads (e.g. spouse chat with 800+ messages), loops are clustered by local message position so that each task is evaluated against its true subsequent conversational context rather than an arbitrary chat-level cutoff.
- **Conservative Closure**: To avoid the heavy scoring penalty of marking open work as done, tasks are only marked `done` or `dropped` when a verifiable, chronological later message exists. If an intervening loop on the same subject arises, attribution remains conservative to prevent premature closure.

## 4. Assistance Decisions (`assist`, `remind`, `leave`)

- **Ownership-First Guardrail**: Tasks owed by anyone other than Arjun are strictly forced to `leave`. Arjun's assistant never intervenes in other people's responsibilities.
- **Assist vs. Remind**:
  - `assist`: Applied when the next step is private, reversible research or preparation (e.g. drafting an email, gathering quotes, comparing flight options). Emits a concrete single-line `next_step` and boolean `needs_yes`.
  - `remind`: Applied when physical presence, personal payment, or a executive decision is required. Automatically generates valid ISO 8601 timestamps in IST (`+05:30`) scheduled during waking hours before deadlines.
  - `leave`: Applied to delicate personal/family conversations, health matters, and ambiguous requests.

## 5. Measured Dev Results & Limitations

- **Offline Baseline & Dev Score**: On the 4,502-message development dataset, the official checker scores the hybrid cached run at **20.8 / 56** (Circles: 7.3/12 [0.61], Organisations: 1.4/8 [0.17], Chats: 6.6/8 [0.83], Loops Found: 3.1/14 [0.23], Loops Closed: 2.3/14 [0.16]).
- **Identified Limitations**:
  - *Short Indirect Requests*: Highly abbreviated asks without explicit verbs can still be under-detected without continuous full-context LLM re-reading.
  - *Subtle Resolutions*: Informal completion acknowledgments (such as an emoji or an unrelated topic transition) are intentionally left open by the conservative closure guardrail to avoid false-done penalties.
  - *Secondary Organisations*: Non-seed secondary ventures (satellite offices, farmhouses) rely heavily on LLM cross-group entity extraction.
