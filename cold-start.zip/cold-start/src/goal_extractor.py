"""Goals: candidates from Arjun's messages (compact, per-chat windows), then one consolidation call (max 10)."""
from .context import clip
from .preprocessing import useful, windows
from .util import LEAN, pmap

CAND = """TASK:goal_candidates. From Arjun's (shown as "{me_name}") WhatsApp chat excerpt (English/Hindi/Bengali/Hinglish) list LONG-TERM goals he expresses or
strongly implies (not one-off tasks). Reply JSON only: {{"goals":[{{"text":"","area":"one of {areas}","type":"one of {types}",
"horizon":"one of {hz}","evidence":["message ids from the excerpt"]}}]}}. Return {{"goals":[]}} if none."""
MERGE = """TASK:goal_merge. Merge duplicates of the same goal, drop weak/temporary ones, keep at most 10. Keep evidence ids unchanged
(union when merging). Same JSON format: {{"goals":[...]}}"""


def run(ctx, max_goals=10, max_windows=40 // LEAN):
    cands = []
    wins = []
    for cid, ms in ctx.by_chat.items():
        mine = [m for m in ms if m["sender"] == ctx.self_id and len(m["text"]) >= 25]
        if len(mine) >= 2:
            for w in windows([m for m in ms if useful(m)], max_chars=9000 * LEAN):
                n = sum(1 for m in w if m["sender"] == ctx.self_id and len(m["text"]) >= 25)
                wins.append((n, w))
    wins.sort(key=lambda x: -x[0])
    sysmsg = CAND.format(areas=ctx.enums["area"], types=ctx.enums["gtype"], hz=ctx.enums["horizon"], me_name=ctx.label(ctx.self_id))
    def work(item):
        try:
            res = ctx.llm.chat_json(sysmsg, "\n".join(ctx.line(m) for m in item[1]), max_tokens=700)
            return [g for g in res.get("goals", []) if isinstance(g, dict)]
        except Exception as e:
            import sys
            print("[goals] window failed: %s" % (type(e).__name__ + ": " + str(e)[:150]), file=sys.stderr)
            return []

    for part in pmap(work, wins[:max_windows]):
        cands += part
    if not cands:
        return []
    try:
        res = ctx.llm.chat_json(MERGE, str(cands)[:30000], max_tokens=1500)
        cands = [g for g in res.get("goals", []) if isinstance(g, dict)] or cands
    except Exception as e:
        import sys
        print("[goals] merge failed: %s" % (type(e).__name__ + ": " + str(e)[:150]), file=sys.stderr)
    out = []
    for g in cands:
        ev = [str(e) for e in g.get("evidence", []) if str(e) in ctx.by_id]
        area, typ, hz = clip(g.get("area"), ctx.enums["area"]), clip(g.get("type"), ctx.enums["gtype"]), clip(g.get("horizon"), ctx.enums["horizon"])
        if not (g.get("text") and ev and area and typ and hz):
            continue  # unsupported or malformed goals are dropped, never padded
        if any(o["text"].lower() == str(g["text"]).lower() for o in out):
            continue
        out.append({"text": g["text"], "area": area, "type": typ, "horizon": hz, "evidence": ev})
    return out[:max_goals]
