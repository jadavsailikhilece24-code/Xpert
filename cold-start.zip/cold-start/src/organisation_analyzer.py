"""Organisations (Arjun's own: companies, home, society, kids' school...) and person->org links (runs / supports).
Seed names are the starting point; groups are sampled for discovery. A client's company is NOT an organisation."""
import sys

from .context import clip

SYSTEM = """TASK:orgs. Arjun's WhatsApp data. Identify the organisations ARJUN owns, runs or belongs to: his companies, his workspace/office, his home,
holiday homes/farmhouse, housing society, his children's schools. A client's, vendor's or customer's own company is NOT Arjun's organisation (they are
people in the client/vendor circle). A WhatsApp group is not automatically an organisation; many groups belong to one company. Always include Arjun's home as an organisation (type residence, side home); household staff (cook, driver, cleaner) support it. Do not invent
organisations: a handful is typical. Known orgs (always include them, with their details): {known}.
For each org give: name, type from {types}, side from {sides}, role = Arjun's role from {roles}
(owner: he owns/runs it, including his own home; partner: co-owner; helper: he assists/advises another's company; resident: he is a society member;
parent: his child's school; member: other membership).
Links: people who run an org with Arjun (co-founders, partners, colleagues running the company) -> runs; people who work for it (cook, driver, cleaner,
caretaker, office staff, employees) -> supports (link in {links}). Use only person ids from the list. Reply JSON only:
{{"orgs":[{{"key":"o1","name":"","type":"","side":"","role":""}}],"links":[{{"person_id":"","org":"o1","link":""}}]}}"""


def _same(a, b):
    a, b = a.strip().lower(), b.strip().lower()
    return a == b or (min(len(a), len(b)) >= 5 and (a in b or b in a))


def run(ctx, people):
    known = [o["name"] for o in ctx.seed.get("orgs", [])]
    pids = {p["id"] for p in people}
    blocks = []
    for cid, c in ctx.chats.items():
        if c["group"]:
            mem = [p for p in c["members"] if p != ctx.self_id][:8]
            blocks.append("## chat %s '%s' members=%s\n%s" % (cid, c["name"], mem, "\n".join(ctx.snippet(cid, 4))))
    pl = "\n".join("%s %s circle=%s" % (p["id"], p["name"], p["circle"]) for p in people
                   if p["circle"] in ("colleague", "partner", "staff", "vendor", "client"))
    user = "PEOPLE:\n%s\n\nGROUPS:\n%s" % (pl, "\n".join(blocks[:80]))
    sysmsg = SYSTEM.format(known=known, types=ctx.enums["otype"], sides=ctx.enums["side"], roles=ctx.enums["role"], links=ctx.enums["link"])
    try:
        res = ctx.llm.chat_json(sysmsg, user[:60000], max_tokens=8000)
    except Exception as e:
        print("[orgs] LLM failed: %s" % (type(e).__name__ + ": " + str(e)[:150]), file=sys.stderr)
        res = {}
    orgs = []
    for o in ctx.seed.get("orgs", []):
        orgs.append({"id": "org_%d" % (len(orgs) + 1), "name": o["name"], "type": o.get("type"), "side": o.get("side"),
                     "role": o.get("role"), "source": "seed"})
    keymap = {}
    for o in res.get("orgs", []) if isinstance(res, dict) else []:
        if not isinstance(o, dict) or not o.get("name"):
            continue
        ex = next((x for x in orgs if _same(x["name"], str(o["name"]))), None)
        if ex is None:
            ex = {"id": "org_%d" % (len(orgs) + 1), "name": o["name"], "type": None, "side": None, "role": None, "source": "llm"}
            orgs.append(ex)
        ex["type"] = ex["type"] or o.get("type")
        ex["side"] = ex["side"] or o.get("side")
        ex["role"] = ex["role"] or o.get("role")
        keymap[o.get("key")] = ex["id"]
    if not any(o["type"] == "residence" for o in orgs):
        orgs.append({"id": "org_%d" % (len(orgs) + 1), "name": "Home", "type": "residence", "side": "home", "role": "owner", "source": "llm"})
    # coerce to the official enums; seeded orgs default to Arjun's own work company
    for o in orgs:
        seeded = o["source"] == "seed"
        o["type"] = clip(o["type"], ctx.enums["otype"], "company" if seeded else "other")
        o["side"] = clip(o["side"], ctx.enums["side"], "home" if o["type"] in ("residence", "vacation home") else "work")
        o["role"] = clip(o["role"], ctx.enums["role"], "owner" if seeded else "other")
    links, seenl = [], set()
    for l in res.get("links", []) if isinstance(res, dict) else []:
        if not isinstance(l, dict):
            continue
        pid, oid, lt = str(l.get("person_id")), keymap.get(l.get("org")), clip(l.get("link"), ctx.enums["link"])
        if pid in pids and oid and lt and (pid, oid) not in seenl:
            seenl.add((pid, oid))
            links.append({"person_id": pid, "org_id": oid, "link": lt})
    return orgs, links
