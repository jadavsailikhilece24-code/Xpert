"""Detect candidate open loops per chat window. Statuses are NOT decided here (see loop_tracker)."""
import re

from .context import clip
from .preprocessing import useful, windows
from .util import LEAN, pmap

SYSTEM = """TASK:loops. Find open loops (pending work an assistant should track) in this WhatsApp excerpt (English/Hindi/Bengali/Hinglish).
Arjun is sender id {me}, shown as "{me_name}". Types:
- commitment: Arjun promised, agreed, or was asked/told to do something he must act on (pay, send, arrange, ask someone, call, check).
  A request or instruction sent TO Arjun is a commitment owed by Arjun; message_id = the request message.
- followup: Arjun is waiting for someone else to deliver or reply (owner = that person).
- deadline: something is due on/by a date or time (owner = whoever must do it, usually Arjun).
- question: a question or decision Arjun must answer or make (owner Arjun), or one he is waiting on (owner = the other person).
Arjun's own loops are mostly PERSONAL asks and promises in one-to-one chats and small groups (family, friends, close contacts: pay someone, order/buy/arrange
something, decide, reply, meet, send). Operational tickets sent to a team in company/support/operations groups (ad ids, refunds, payment issues, formatting,
customer complaints, "plz check") are the team's work, NOT Arjun's loops, unless Arjun himself says he will do it. Only real actionable work. SKIP: greetings, thanks, jokes, news/link forwards, opinions, general statements, finished actions, hypotheticals,
bare acknowledgements ("ok"), things that need no action from anyone. ONE loop per task even if repeated or discussed across several messages
(use the message that first creates it). The excerpt may contain several chats ("=== chat ... ==="); message_id must come from it. title: short imperative with names/amounts ("Pay Nayna Rs 3,500"). owner: "self" for Arjun, otherwise that
person's sender id. due: YYYY-MM-DD only if a date is stated or clearly implied (resolve "tomorrow"/"Friday" from the message date), else null.
Reply JSON only: {{"loops":[{{"title":"","type":"","owner":"","message_id":"","due":null}}]}}"""


def _tok(s):
    return set(re.findall(r"\w+", s.lower()))


def dup(a, b):
    ta, tb = _tok(a), _tok(b)
    return bool(ta and tb) and len(ta & tb) / len(ta | tb) >= 0.6


def _near(ctx, a, b, days=3):
    """Only treat similar titles as the same task when raised within a few days (a recurring task weeks later is a new loop)."""
    ta, tb = ctx.by_id[a]["ts"], ctx.by_id[b]["ts"]
    return ta is None or tb is None or abs(ta - tb) <= days * 86400


def resolve_owner(ctx, chat_id, owner):
    o = str(owner).strip()
    if o.lower() in ("self", "arjun", "me") or o == ctx.self_id or o == ctx.label(ctx.self_id):
        return ctx.self_id
    if o in ctx.senders:
        return o
    rev = {ctx.label(s).lower(): s for s in ctx.senders}
    rev.update({ctx.label(s).lower().split()[0]: s for s in ctx.senders if ctx.label(s).strip()})
    if o.lower() in rev:
        return rev[o.lower()]
    if o == "OTHER":
        others = [m for m in ctx.chats[chat_id]["members"] if m != ctx.self_id]
        return others[0] if len(others) == 1 else None
    return None


def _big(ctx, cid):
    """Team/ops groups (more than 5 participants) hold lots of traffic but almost none of Arjun's own loops."""
    c = ctx.chats[cid]
    return c["group"] and len(c["members"]) > 5


def _cost(w):
    return sum(len(m["text"][:280]) + 40 for m in w)


def _batches(items, cap):
    """Pack consecutive (chat, window) items into calls of at most `cap` chars: many small chats share one call (fewer requests)."""
    out, cur, size = [], [], 0
    for it in items:
        c = _cost(it[1])
        if cur and size + c > cap:
            out.append(cur)
            cur, size = [], 0
        cur.append(it)
        size += c
    if cur:
        out.append(cur)
    return out


def _call(ctx, batch):
    sysmsg = SYSTEM.format(me=ctx.self_id, me_name=ctx.label(ctx.self_id))
    user = "\n".join("=== chat %s '%s' ===\n%s" % (cid, ctx.chats[cid]["name"], "\n".join(ctx.line(m) for m in w)) for cid, w in batch)
    try:
        res = ctx.llm.chat_json(sysmsg, user, max_tokens=2500)
        return res.get("loops", []) if isinstance(res, dict) else []
    except Exception as e:
        import sys
        print("[loops] call failed: %s" % (type(e).__name__ + ": " + str(e)[:150]), file=sys.stderr)
        return []


def run(ctx):
    cap = 7000 * LEAN
    items = []
    for cid, ms in ctx.by_chat.items():
        if cid not in ctx.chats:
            continue
        for w in windows([m for m in ms if useful(m)], max_chars=cap):
            if len(w) < 3:
                continue
            if _big(ctx, cid) and not any(m["sender"] == ctx.self_id for m in w):
                continue  # nothing from Arjun in this stretch of a big group: skip it (also saves cost)
            items.append((cid, w))
    batches = _batches(items, cap)
    results = pmap(lambda b: _call(ctx, b), batches)
    mine_by_chat = {}
    for batch, rows in zip(batches, results):
        ids = {m["id"] for _, w in batch for m in w}
        for r in rows:
            if not isinstance(r, dict):
                continue
            mid, typ, title = str(r.get("message_id")), clip(r.get("type"), ctx.enums["ltype"]), r.get("title")
            if mid not in ids or not typ or not title:
                continue  # never keep a loop whose origin message we cannot verify
            cid = ctx.by_id[mid]["chat"]
            if _big(ctx, cid) and ctx.by_id[mid]["sender"] != ctx.self_id:
                continue  # a request in a big team group is the team's work, not Arjun's loop
            owner = resolve_owner(ctx, cid, r.get("owner"))
            if owner is None:
                continue  # no verifiable owner -> no loop
            mine = mine_by_chat.setdefault(cid, [])
            if any(l["message_id"] == mid or (dup(l["title"], title) and l["owner"] == owner and _near(ctx, l["message_id"], mid))
                   for l in mine):
                continue
            due = r.get("due") if isinstance(r.get("due"), str) and re.match(r"\d{4}-\d{2}-\d{2}", r["due"]) else None
            mine.append({"title": title, "type": typ, "owner": owner, "chat_id": cid, "message_id": mid,
                         "due": due[:10] if due else None, "status": "open", "resolution_message_id": None})
    loops = [l for cid in ctx.by_chat if cid in mine_by_chat for l in mine_by_chat[cid]]
    for i, l in enumerate(loops, 1):
        l["id"] = "loop_%d" % i
    return loops