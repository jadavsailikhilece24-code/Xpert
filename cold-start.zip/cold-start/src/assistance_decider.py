"""assist / remind / leave for every still-open loop. Defaults to 'leave' whenever the evidence is not clear."""
import datetime as dt

from .context import clip
from .util import pmap

SYSTEM = """TASK:assist. For each OPEN loop choose exactly one action for Arjun's AI assistant:
assist = the assistant can move it forward itself with something private and reversible (research options, compare, find slots, draft a reply,
prepare a document, organise information). Give next_step (one line) and needs_yes (true if the step would send/book/pay/commit anything or
cannot be undone; false for pure research/drafting for Arjun's eyes).
remind = only Arjun can do it (pay, decide, call, attend, physical action) and he may forget: give remind_at as an ISO date-time with +05:30 offset,
before any due date, in waking hours (otherwise next morning 09:00), plus a short reason.
leave = stay out: someone else owes it, staff/family already handle it, it is personal or sensitive (spouse, family, health, money between family),
a nudge would be intrusive or unnecessary, or it is already being managed. Give a short reason.
The assistant never books, pays, sends or commits externally on its own. If the owner is not Arjun choose leave. When unsure prefer leave: pointless
reminders and unwanted help are the worst outcomes. Reply JSON only:
{{"decisions":[{{"id":"","action":"","next_step":null,"needs_yes":null,"remind_at":null,"reason":""}}]}}"""


def _iso(v):
    if not v:
        return None
    s = str(v).strip().replace("Z", "+00:00")
    try:
        d = dt.datetime.fromisoformat(s)
        if d.tzinfo is None:
            ist = dt.timezone(dt.timedelta(hours=5, minutes=30))
            d = d.replace(tzinfo=ist)
        return d.isoformat()
    except ValueError:
        return None


def _default_remind_at(due, origin_ts):
    ist = dt.timezone(dt.timedelta(hours=5, minutes=30))
    if due:
        try:
            d = dt.date.fromisoformat(due[:10])
            remind_d = d - dt.timedelta(days=1)
            return dt.datetime(remind_d.year, remind_d.month, remind_d.day, 9, 0, 0, tzinfo=ist).isoformat()
        except ValueError:
            pass
    if origin_ts:
        try:
            base = dt.datetime.fromtimestamp(float(origin_ts), ist)
            next_d = base + dt.timedelta(days=1)
            return dt.datetime(next_d.year, next_d.month, next_d.day, 9, 0, 0, tzinfo=ist).isoformat()
        except (ValueError, TypeError):
            pass
    return "2026-10-01T09:00:00+05:30"


def run(ctx, loops, batch=12):
    open_loops = [l for l in loops if l["status"] == "open"]
    for l in loops:
        l.update({"action": None, "next_step": None, "needs_approval": None, "remind_at": None, "reason": None})
    parts = [open_loops[i:i + batch] for i in range(0, len(open_loops), batch)]

    def work(part):
        blocks = []
        for l in part:
            ctxl = [ctx.line(m) for m in ctx.by_chat[l["chat_id"]] if m["id"] == l["message_id"]]
            ts = ctx.by_id[l["message_id"]]["ts"]
            iso = dt.datetime.fromtimestamp(ts, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") if ts is not None else "unknown"
            blocks.append("%s: %s | type=%s | owner=%s | due=%s | origin_ts=%s | chat='%s'\n  %s" % (
                l["id"], l["title"], l["type"], "ARJUN" if l["owner"] == ctx.self_id else ctx.label(l["owner"]), l["due"], iso,
                ctx.chats[l["chat_id"]]["name"], " ".join(ctxl)))
        try:
            res = ctx.llm.chat_json(SYSTEM, "\n".join(blocks), max_tokens=1500)
            rows = {str(r.get("id")): r for r in res.get("decisions", []) if isinstance(r, dict)}
        except Exception as e:
            import sys
            print("[assist] batch failed: %s" % (type(e).__name__ + ": " + str(e)[:150]), file=sys.stderr)
            rows = {}
        for l in part:
            r = rows.get(l["id"], {})
            act = clip(r.get("action"), ctx.enums["action"], "leave")
            if l["owner"] != ctx.self_id:
                act = "leave"           # others' tasks are never ours to chase
            if act == "assist" and not r.get("next_step"):
                act = "leave"
            l["action"] = act
            l["reason"] = r.get("reason") or ("No clear basis to intervene." if act == "leave" else None)
            if act == "assist":
                ny = r.get("needs_yes") if r.get("needs_yes") is not None else r.get("needs_approval", True)
                l["next_step"], l["needs_approval"] = r["next_step"], bool(ny)
            elif act == "remind":
                rat = _iso(r.get("remind_at"))
                if not rat:
                    ts = ctx.by_id.get(l["message_id"], {}).get("ts")
                    rat = _default_remind_at(l.get("due"), ts)
                l["remind_at"] = rat
    pmap(work, parts)
    return loops
