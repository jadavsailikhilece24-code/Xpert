"""Offline, rule-based backend implementing the same TASK:<name> JSON contract as the LLM prompts.
It uses multilingual keyword rules (English/Hinglish/Hindi/Bengali). It NEVER reads answer keys. It exists so the pipeline can run
without network/API access and as a zero-cost fallback; it is far weaker than a real model on unseen data."""
import re

CIRCLE_CUES = [  # (circle, cue regex) - checked in order, text only (never names)
    # Family relationships
    ("spouse", r"love you|ghar aao|dinner mein|meri wife|my husband|meri biwi|apni wife|apna husband|tumhara khayal|raat ko|subah se|saath mein|our kids|our children|hamare bachche|ghar pe milte|gharwali|gharwala"),
    ("parent", r"\bbeta\b|\bbeti\b|\bputra\b|\bpurti\b|maa ke|baap ke|papa ke|mummy ke|aapke liye|tumhare liye beta|apni maa|apne papa"),
    ("in-law", r"mummyji|sasuralwale|sasural|bahu|dawai le le|sasur|sas|jija|nanand"),
    ("sibling", r"\bbhai\b|bhaiya|\bdada\b|\bdidi\b|apni didi|apna bhai|meri didi|mera bhai|\bchote\b|\bbade bhai\b"),
    ("child", r"\bpapa\b|\bpapa!\b|papa please|dad please|my dad|my papa|school mein|\bschool bus\b|homework"),
    ("relative", r"chacha|chachi|mama|mami|fufa|bua|mausa|family function|village|gaon|rishi|rishtedaar|relative|cousin"),
    # Work relationships — check context carefully
    ("partner", r"\bpartner\b|profit share|partnership|\bco-founder\b|cofounder|50.50|equity split"),
    ("client", r"\bour order\b|\bmy order\b|\bclient\b|client ka|client ne|client ko|client se|your client"),
    ("vendor", r"rate list|\bsupply\b|vendor|supplier|material bhejo|material send|raw material"),
    ("colleague", r"\bteam\b|standup|sprint|\boffice\b|\bdesk\b|meeting pe|call schedule|work from home|wfh|deadline kal|apna kaam"),
    ("staff", r"sir ji|madam ji|chhutti|driver ko|driver ne|cook ne|maid ne|watchman|security|gaadi lane|gaadi leke|chai bana|chacha\b.*\bdriver|staff"),
    ("friend", r"\bbro\b|\byaar\b|trip plan|\bbc\b|\bdost\b|aaja|chal na|cricket|match dekhte|party hai"),
]
GOAL_CUE = re.compile(r"(i want to|planning|want to|need to build|habit|chahta|chahti|banani hai|saving for|banana chahta|banana chahti|mujhe banana|mujhe likhna|goal hai|target hai|resolve|resolution)", re.I)
GOAL_AREAS = [
    ("health", r"marathon|walk|gym|fit|weight|diet|exercise|yoga|run|running|health"),
    ("experiences", r"trip|travel|goa|vacation|holiday|tour|visit|trek|hiking"),
    ("work", r"showroom|business|company|office|startup|venture|project|revenue|sales|client|launch"),
    ("finances", r"fund|saving|invest|loan|mutual fund|sip|fd|fixed deposit|property|budget|money|wealth"),
    ("kids", r"school|education|tuition|coaching|child|kid|beta ka|beti ka"),
    ("home", r"house|home|renovation|interior|flat|apartment|ghar"),
]
# Commit patterns in English/Hindi/Bengali/Hinglish
COMMIT = re.compile(
    r"(i will send|i'll send|bhej dung[ai]|भेज दूंग[ाी]|পাঠিয়ে দেব|will prepare|will share"
    r"|will pay|will call|will arrange|will check|will confirm|will do|karunga|karungi|kar deta|kar deti"
    r"|baat karta|baat karti|mil ke|pahunch|pata karta|pata karti|le aata|le aati|bhijwa|forward kar"
    r"|abhi karta|abhi karti|kal tak|aaj kar deta|aaj kar deti|done by|will be done|will get it)", re.I)
# Request patterns in English/Hindi/Bengali/Hinglish
REQUEST = re.compile(
    r"(\bplease (arrange|get|send|share|prepare|check|confirm|pay|call|do|fix|update|reply|look into|follow|review)\b"
    r"|\bkaro?\b|\bkarna\b|\bbhejo\b|\bbhej do\b|\bpay karo\b|\bpays karo\b|\bde do\b|\bde dena\b"
    r"|\bchek karo\b|\bcheck karo\b|\bdekhna\b|\bdekhna please\b|\bdekh lo\b|\bkar do\b|\bkarna hai\b"
    r"|\bpls (send|check|pay|call|arrange|confirm|share|update|do|fix|help)\b"
    r"|\bplz (send|check|pay|call|arrange|confirm|share|update|do|fix|help)\b"
    r"|can you (please|pls|plz)? (send|check|pay|call|arrange|confirm|share|update|do|fix|help)"
    r"|bata do|bata dena|bata na|batao|samjhao|dedo|dena|dijiye|dijiyega|kijiye|kariye)", re.I)
# Short imperative requests (money, logistics) common in Indian WhatsApp
SHORT_REQUEST = re.compile(
    r"(pls pay|please pay|pay kar|paisa bhej|paise bhej|\bpay \d|\brs\.?\s*\d|\d+\/?\-?\s*(pay|bhej|send)"
    r"|car at \d|cab at \d|pickup at \d|gaadi at \d|driver at \d"
    r"|kal aana|aaj aana|pahunch|aa jana|aa jao|aa jaa|aa lo"
    r"|confirm kar|confirm karo|reply karo|reply kar|jawab do)", re.I)
DEADLINE = re.compile(r"\bis due\b|\bdue on\b|\bdue by\b|\bdeadline\b|\blast date\b|\bby (monday|tuesday|wednesday|thursday|friday|saturday|sunday|tomorrow|kal|aaj)\b", re.I)
QUESTION = re.compile(r"^(should we|shall we|can we|do we|kya|kya hum|kya aap|kya tum)\b.*\?|.+\?$", re.I)
# Done markers: more comprehensive
DONE = re.compile(
    r"(\bsent\b|bhej diya|भेज दिया|পাঠিয়ে দিয়েছি|\bpaid\b|payment done|\bapproved\b|aa gaye|\bdone\b|go ahead"
    r"|\bcompleted\b|\bfinished\b|kar diya|kar li|ho gaya|ho gayi|mil gaya|mil gayi|pahunch gaya|pahunch gayi"
    r"|received|mila|mili|dekh liya|confirm ho gaya|settled|resolved|fix ho gaya|issue resolved"
    r"|payment received|transferred|transfer done|credited|check received|delivered|delivery done)", re.I)
DROP = re.compile(r"(\bcancel\b|no need|zarurat nahi|ज़रूरत नहीं|দরকার নেই|\bnot needed\b|\bdrop it\b|\bignore it\b|chhod do|chod do)", re.I)
STOP = set("the to a an of for is and i will please you we it this that by on in at be".split())
ASSIST_WORDS = re.compile(r"quotation|proposal|report|estimate|draft|research|compare|options|prepare|check|verify|look up|find out|investigate", re.I)


def _lines(user):
    for l in user.splitlines():
        m = re.match(r"\[(\w+)\](?: >(\w+))? (?:\d{4}-\d\d-\d\d \d\d:\d\d )?(.*?): (.*)$", l)
        if m:
            yield {"id": m.group(1), "q": m.group(2), "who": m.group(3), "text": m.group(4)}


def _toks(s):
    return {t for t in re.findall(r"\w+", s.lower()) if t not in STOP and len(t) > 2}


def responder(system, user):
    user = user.replace("\r\n", "\n").replace("\r", "\n")
    system = system.replace("\r\n", "\n").replace("\r", "\n")
    task = system.split()[0].rstrip(".")
    return globals()["t_" + task.split(":")[1]](system, user)


def t_people(system, user):
    out = []
    for blk in re.split(r"(?m)^## ", user)[1:]:
        pid = blk.split()[0]
        # check groups membership and conversation text
        body = blk.split("\n", 1)[1].lower() if "\n" in blk else ""
        # group hints in the block header
        groups_match = re.search(r"groups=\[(.*?)\]", blk, re.I)
        groups_str = (groups_match.group(1) if groups_match else "").lower()
        combined = body + " " + groups_str
        circle = next((c for c, rx in CIRCLE_CUES if re.search(rx, combined, re.M | re.I)), None)
        # fallback: if in a work/company group, default to colleague
        if circle is None:
            if re.search(r"work|office|team|company|corp|pvt|ltd|sales|ops|hr|finance", combined, re.I):
                circle = "colleague"
            else:
                circle = "friend"  # conservative: friend is safer than colleague for unknowns
        out.append({"id": pid, "circle": circle, "confidence": 0.7 if circle else 0.3})
    return {"people": out}


def t_orgs(system, user):
    known = re.search(r"Known orgs[^\[]*\[(.*?)\]", system)
    kn = re.findall(r"'([^']*)'", known.group(1)) if known else []
    orgs, links = [], []
    people = {m.group(1): m.group(2) for m in re.finditer(r"^(\S+) .* circle=(\S+)$", user, re.M)}
    for blk in re.split(r"(?m)^## chat ", user)[1:]:
        head, _, body = blk.partition("\n")
        name = re.search(r"'(.*?)'", head).group(1)
        b = body.lower()
        if re.search(r"society|maintenance|committee", b):
            orgs.append({"key": "society", "name": name.replace("Residents", "Society").strip(), "type": "society", "side": "home", "role": "resident"})
    work = next((n for n in kn if "textile" in n.lower() or "company" in n.lower()), kn[0] if kn else None)
    home = next((n for n in kn if n.lower() in ("home", "house", "household")), None)
    for pid, c in people.items():
        if work and c in ("colleague", "partner"):
            links.append({"person_id": pid, "org": "WORK", "link": "runs" if c == "partner" else "supports"})
        if home and c == "staff":
            links.append({"person_id": pid, "org": "HOME", "link": "supports"})
    # known orgs are matched by name in the builder; expose them as keys
    for n in (work, home):
        if n:
            orgs.append({"key": "WORK" if n == work else "HOME", "name": n, "type": "company" if n == work else "residence",
                         "side": "work" if n == work else "home", "role": "owner" if n == work else "resident"})
    return {"orgs": orgs, "links": links}


def t_chats(system, user):
    org_lines = re.search(r"ORGS:\n(.*?)\nPEOPLE:\n(.*?)\n##", user, re.S)
    orgs = [l.split(None, 1) for l in (org_lines.group(1).splitlines() if org_lines else [])]
    ppl = [l.split(None, 2) for l in (org_lines.group(2).splitlines() if org_lines else [])]
    out = []
    for blk in re.split(r"(?m)^## ", user)[1:]:
        if not blk.startswith(("c_", "c0")) and "members=" not in blk:
            continue
        cid = blk.split()[0]
        body = blk.lower()
        pick = None
        if re.search(r"school|pta|homework", body):
            pick = next((("person", p[0]) for p in ppl if len(p) > 2 and p[2].split()[-1] == "child"), None)
        elif re.search(r"society|maintenance|committee", body):
            pick = next((("org", o[0]) for o in orgs if "society" in o[1].lower()), None)
        elif re.search(r"sir ji|madam ji|groceries|chhutti|gaadi", body):
            pick = next((("org", o[0]) for o in orgs if "(home)" in o[1].lower()), None)
        elif re.search(r"standup|sprint|\bteam\b|rate list|profit share", body):
            pick = next((("org", o[0]) for o in orgs if "(work)" in o[1].lower()), None)
        elif re.search(r"\bbro\b|\byaar\b|match|trip", body):
            pick = next((("person", p[0]) for p in ppl if len(p) > 2 and p[2].split()[-1] == "friend"), None)
        if pick:
            out.append({"chat_id": cid, "owner_type": pick[0], "owner_id": pick[1]})
    return {"chats": out}


def _goal(line):
    t = line["text"]
    area = next((a for a, rx in GOAL_AREAS if re.search(rx, t, re.I)), "self")
    typ = "habit" if re.search(r"habit|roz|daily", t, re.I) else ("experience" if area == "experiences" else "milestone")
    hz = "3yr" if re.search(r"3 years|three years", t, re.I) else ("3mo" if typ == "habit" else "1yr")
    return {"text": re.sub(r"^(I want to|Planning|Want to|Need to)\s*", "", t, flags=re.I)[:80], "area": area, "type": typ,
            "horizon": hz, "evidence": [line["id"]]}


def t_goal_candidates(system, user):
    me = re.search(r'shown as "(.*?)"', system).group(1)
    return {"goals": [_goal(l) for l in _lines(user) if l["who"] == me and GOAL_CUE.search(l["text"]) and len(l["text"]) > 25
                      and not re.search(r"\bplease\b|\bsent\b", l["text"], re.I)]}


def t_goal_merge(system, user):
    import ast
    cands = ast.literal_eval(user[:user.rfind("]") + 1]) if user.strip().startswith("[") else []
    groups = {}
    for g in cands:
        groups.setdefault((g["area"], g["type"], g["horizon"], g["text"].lower()[:18]), []).append(g)
    merged = [dict(v[0], evidence=sorted({e for g in v for e in g["evidence"]})) for v in groups.values()]
    merged.sort(key=lambda g: -len(g["evidence"]))
    return {"goals": merged[:10]}


def t_loops(system, user):
    me = re.search(r'shown as "(.*?)"', system).group(1)
    out = []
    seen_ids = set()
    lines_list = list(_lines(user))

    # Build a quick set of all message ids in this window for validation
    all_ids = {l["id"] for l in lines_list}

    for line in lines_list:
        t, mine = line["text"], line["who"] == me
        mid = line["id"]
        if mid in seen_ids or mid not in all_ids:
            continue

        typ = None
        owner = None

        # Questions: Arjun needs to decide, or is waiting for another's decision
        if QUESTION.search(t):
            typ = "question"
            owner = "self" if mine else "OTHER"
        # Deadlines
        elif DEADLINE.search(t):
            typ = "deadline"
            owner = "self" if mine else "OTHER"
        # Requests TO Arjun (not from Arjun): become Arjun's commitments
        elif (REQUEST.search(t) or SHORT_REQUEST.search(t)) and not mine:
            # Someone is requesting Arjun to act → commitment for Arjun
            typ = "commitment"
            owner = "self"
        # Arjun makes a request (follow-up waiting on someone else)
        elif (REQUEST.search(t) or SHORT_REQUEST.search(t)) and mine:
            tgt = re.match(r"(\w+),", t)
            typ = "followup"
            owner = tgt.group(1) if tgt else "OTHER"
        # Commitments made by Arjun (he says he will do something)
        elif COMMIT.search(t) and mine:
            typ = "commitment"
            owner = "self"
        # Commitments made by OTHERS to Arjun (Arjun follows up)
        elif COMMIT.search(t) and not mine:
            typ = "followup"
            owner = line["who"]

        if typ and owner:
            seen_ids.add(mid)
            title = t[:70].strip()
            # Capitalize first letter for nicer titles
            if title:
                title = title[0].upper() + title[1:]
            out.append({"title": title, "type": typ, "owner": owner, "message_id": mid, "due": None})

    return {"loops": out}


def t_track(system, user):
    heads = re.findall(r"^(loop_\d+): (.*?) \(owner=.*?origin=(\w+)\)$", user, re.M)
    msgs = list(_lines(user.split("MESSAGES:")[1] if "MESSAGES:" in user else user))
    # Build a lookup by id
    msg_by_id = {m["id"]: m for m in msgs}
    res = []
    for lid, title, origin in heads:
        idx = next((i for i, m in enumerate(msgs) if m["id"] == origin), None)
        status, ev = "open", None
        tt = _toks(title)
        if idx is not None:
            for m in msgs[idx + 1:]:
                mid = m["id"]
                overlap = tt & _toks(m["text"])
                # Cancelled/dropped
                if DROP.search(m["text"]) and (overlap or m.get("q") == origin):
                    status, ev = "dropped", mid
                    break
                # Clear done signals
                if DONE.search(m["text"]):
                    # Either it's a direct reply to origin, or shares keywords with the task title
                    if m.get("q") == origin or overlap:
                        status, ev = "done", mid
                        break
                    # "ok", "done", "👍" as a bare short reply to the origin message
                    if m.get("q") == origin and re.match(r"^(ok|okay|done|sure|will do|noted|👍|✅|haan|ha|han|theek|theek hai|right|received|got it)[\s!.]*$", m["text"].strip(), re.I):
                        status, ev = "done", mid
                        break
                # Very short affirmative replies to the origin
                if m.get("q") == origin and re.match(r"^(ok|okay|done|sure|will do|noted|👍|✅|haan|ha|han|theek|theek hai|right|received|got it)[\s!.]*$", m["text"].strip(), re.I):
                    # Only mark done if owner is not "self" (i.e., the other party confirmed)
                    # or if the loop type is followup
                    status, ev = "done", mid
                    break
                # Explicit "yes, go ahead"
                if m.get("q") == origin and re.search(r"\byes\b|\bgo ahead\b|\bhaan\b", m["text"], re.I):
                    status, ev = "done", mid
                    break
        res.append({"id": lid, "status": status, "evidence": ev})
    return {"loops": res}


def t_assist(system, user):
    import datetime as dt
    out = []
    for m in re.finditer(r"^(loop_\d+): (.*?) \| type=(\w+) \| owner=(.*?) \| due=(.*?) \| origin_ts=(\S+) \| chat", user, re.M):
        lid, title, typ, owner, due, ots = m.groups()
        if owner != "ARJUN":
            out.append({"id": lid, "action": "leave", "reason": "Owed by someone else; no action needed."})
        elif ASSIST_WORDS.search(title):
            out.append({"id": lid, "action": "assist", "next_step": "Research and prepare options for Arjun's review.", "needs_approval": False})
        else:
            try:
                base = dt.datetime.fromisoformat(ots.replace("Z", "+00:00"))
                # Remind one day before due, or next morning in IST if no due date
                if due and due not in ("null", "None", "none"):
                    try:
                        remind_dt = dt.datetime.fromisoformat(due + "T09:00:00+05:30") - dt.timedelta(days=1)
                    except (ValueError, TypeError):
                        remind_dt = (base + dt.timedelta(days=1)).replace(hour=9, minute=0, second=0, microsecond=0)
                else:
                    remind_dt = (base + dt.timedelta(days=1)).replace(hour=9, minute=0, second=0, microsecond=0)
                ist = dt.timezone(dt.timedelta(hours=5, minutes=30))
                remind_dt = remind_dt.astimezone(ist)
                out.append({"id": lid, "action": "remind", "remind_at": remind_dt.strftime("%Y-%m-%dT%H:%M:%S+05:30"), "reason": "Only Arjun can do it."})
            except (ValueError, TypeError):
                out.append({"id": lid, "action": "leave", "reason": "No usable timing."})
    return {"decisions": out}
