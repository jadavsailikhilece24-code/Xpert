"""Configuration loaded from environment variables (never hardcode secrets)."""
import json
import os
from dataclasses import dataclass
from typing import Optional


def _float(name):
    v = os.environ.get(name, "").strip()
    try:
        return float(v) if v else None
    except ValueError:
        return None


def _json(name):
    v = os.environ.get(name, "").strip()
    try:
        d = json.loads(v) if v else None
        return d if isinstance(d, dict) else None
    except ValueError:
        return None


def load_dotenv(path=".env"):
    """Minimal .env reader; existing environment variables win."""
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


@dataclass
class Config:
    base_url: str = ""
    api_key: str = ""
    model: str = ""
    price_in_per_m: Optional[float] = None
    price_out_per_m: Optional[float] = None
    mock: bool = False
    timeout: int = 90
    max_retries: int = 6
    cache_dir: str = ".cache"
    max_rpm: float = 0.0          # 0 = no client-side rate limit (set for free tiers)
    extra_body: dict = None       # optional extra request fields, e.g. {"reasoning_effort": "none"}

    @classmethod
    def from_env(cls):
        return cls(
            base_url=os.environ.get("LLM_BASE_URL", "").rstrip("/"),
            api_key=os.environ.get("LLM_API_KEY", ""),
            model=os.environ.get("LLM_MODEL", ""),
            price_in_per_m=_float("LLM_PRICE_IN_PER_M"),
            price_out_per_m=_float("LLM_PRICE_OUT_PER_M"),
            mock=os.environ.get("LLM_MOCK", "0") == "1",
            max_retries=int(_float("XPERT_MAX_RETRIES") or 6),
            max_rpm=_float("XPERT_MAX_RPM") or 0.0,
            extra_body=_json("LLM_EXTRA_BODY"),
        )

    def validate(self):
        if self.mock:
            return
        missing = [n for n, v in (("LLM_BASE_URL", self.base_url),
                                  ("LLM_API_KEY", self.api_key),
                                  ("LLM_MODEL", self.model)) if not v]
        if missing:
            raise RuntimeError("Missing env vars: " + ", ".join(missing)
                               + " (or set LLM_MOCK=1 for offline mock mode)")
