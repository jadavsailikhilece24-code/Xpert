"""Separate status tracking: replay each chat's messages AFTER the origin and decide open/done/dropped.
Conservative by design: done/dropped require a verifiable later evidence message; otherwise the loop stays open."""
from .context import clip
from .open_loop_detector import dup
from .util import pmap

SYSTEM = """TASK:track. Below are loops (tasks) and the chat messages in this WhatsApp conversation (English/Hindi/Bengali/Hinglish) that came around and AFTER they arose, in order. Decide each loop's status at the END:
done = later messages show the task happened or was settled:
  - Paid/transferred: "paid", "sent", "payment done", "bhej diya", "kar diya", "transferred", "credited", screenshot/slip shared
  - Delivered/booked/arrived: "booked", "delivered", "aa gaya", "pahunch gaya", "gaadi pahunch gayi", "driver aa gaya"
  - Confirmed/completed: "done", "ho gaya", "kar liya", "finished", "completed", "received", "mil gaya"
  - The question was answered, or the decision made, or the waited-for person delivered/replied.
dropped = explicitly cancelled, abandoned or no longer needed ("cancel", "no need", "zarurat nahi", "chhod do", "drop it", "ignore").
open = still pending: only an acknowledgement or future promise ("ok", "will do", "soon", "kal karenge", "dekhunga"), partial progress, a postponement, or nothing relevant followed.
A bare "ok" is done only if it directly and unambiguously confirms completion or a decision in context. If a later message reopens it, use the latest state.
Do not mark done without a deciding message; give that single message id (it must appear in the excerpt and come AFTER the loop origin) as evidence.
Reply JSON only: {{"loops":[{{"id":"","status":"open|done|dropped","evidence":"<message id or null>"}}]}}"""


def run(ctx, loops, max_after=120):
    by_chat = {}
    for l in loops:
        by_chat.setdefault(l["chat_id"], []).append(l)

    # Cluster loops in each chat by position so no loop's subsequent messages are missed
    tasks = []
    for cid, ls in by_chat.items():
        ms = ctx.by_chat.get(cid, [])
        if not ms:
            continue
        pos = {m["id"]: i for i, m in enumerate(ms)}
        valid_ls = [l for l in ls if l["message_id"] in pos]
        if not valid_ls:
            continue
        valid_ls.sort(key=lambda l: pos[l["message_id"]])

        # Group loops whose origin positions are within 60 messages of each other, max 8 per group
        clusters = []
        cur_cluster = [valid_ls[0]]
        for l in valid_ls[1:]:
            if pos[l["message_id"]] - pos[cur_cluster[0]["message_id"]] <= 60 and len(cur_cluster) < 8:
                cur_cluster.append(l)
            else:
                clusters.append(cur_cluster)
                cur_cluster = [l]
        if cur_cluster:
            clusters.append(cur_cluster)

        for cluster in clusters:
            first_idx = pos[cluster[0]["message_id"]]
            last_idx = max(pos[l["message_id"]] for l in cluster)
            end_idx = min(len(ms), last_idx + max_after + 1)
            after = ms[first_idx:end_idx]
            if len(after) > 1:
                tasks.append((cid, cluster, after, pos))

    def work(item):
        cid, cluster, after, pos = item
        head = "\n".join("%s: %s (owner=%s, origin=%s)" % (l["id"], l["title"], ctx.label(l["owner"]), l["message_id"]) for l in cluster)
        user = "LOOPS:\n%s\n\nMESSAGES:\n%s" % (head, "\n".join(ctx.line(m) for m in after))
        try:
            res = ctx.llm.chat_json(SYSTEM, user[:45000], max_tokens=1500)
            rows = res.get("loops", []) if isinstance(res, dict) else []
        except Exception as e:
            import sys
            print("[tracker] chat failed: %s" % (type(e).__name__ + ": " + str(e)[:150]), file=sys.stderr)
            return
        lm = {l["id"]: l for l in cluster}
        for r in rows:
            if not isinstance(r, dict):
                continue
            l = lm.get(str(r.get("id")))
            st = clip(r.get("status"), ctx.enums["status"]) if l else None
            ev = str(r.get("evidence")) if l else None
            if not l or st in (None, "open"):
                continue
            # evidence must exist, be in this chat, and come after the origin message
            if ev in pos and pos[ev] > pos[l["message_id"]]:
                clash = any(o is not l and pos[l["message_id"]] < pos[o["message_id"]] < pos[ev] and dup(l["title"], o["title"])
                            for o in cluster)
                if not clash:
                    l["status"], l["resolution_message_id"] = st, ev

    pmap(work, tasks)
    return loops
