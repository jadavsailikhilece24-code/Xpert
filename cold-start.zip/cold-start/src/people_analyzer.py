"""People: sender/participant ids are identity. Seed circles are preserved; the rest are LLM-classified from cross-chat context
with a conservative fallback. Staff who look after a specific person are recorded in `looks_after`."""
import sys

from .context import clip
from .util import LEAN, pmap

SYSTEM = """TASK:people. You classify people around Arjun (the account owner) from WhatsApp excerpts (English/Hindi/Bengali/Hinglish).
For each person pick exactly one circle from: {circles}. A circle is the person's relationship to Arjun, not closeness
(the cook and the office cleaner are both staff). colleague = works with Arjun in his companies; partner = business partner/co-founder; client = pays
his companies for services; vendor = supplies goods/services to him; relative = extended family; in-law = spouse's family;spouse = shares family life with Arjun (personal/household errands, kids, home, family plans);staff = ONLY household or office support help (cook, driver, cleaner, security, caretaker); people who do business work with Arjun in his companies are colleagues, even if junior. Relatives include cousins, uncles, aunts, nephews and in-laws' relatives; friends are not family. Use relationships implied by what they say or how Arjun addresses them, not the
name alone. Pay attention to indirect references ("my father in law" said BY someone about their own family is not Arjun's in-law).
If evidence is weak choose the most conservative circle supported. For staff who specifically look after another person
(e.g. a driver for the kids) give that person's id in looks_after, else null. Reply JSON only:
{{"people":[{{"id":"<id>","circle":"<circle>","confidence":0-1,"looks_after":null}}]}}"""


def run(ctx, batch=10 * LEAN):
    seed_people = ctx.seed.get("people", {})
    known = set()
    for c in ctx.chats.values():
        known.update(c["members"])
    known.update(ctx.senders)
    known.discard(ctx.self_id)
    known.discard("")
    out, todo = {}, []
    for pid in sorted(known, key=lambda p: (-ctx.senders.get(p, 0), p)):
        if pid in seed_people:
            out[pid] = {"id": pid, "name": ctx.label(pid), "circle": seed_people[pid]["circle"], "confidence": 1.0,
                        "source": "seed", "looks_after": []}
        else:
            todo.append(pid)
    parts = [todo[i:i + batch] for i in range(0, len(todo), batch)]

    def block(pid):
        direct = [cid for cid, c in ctx.chats.items() if not c["group"] and pid in c["members"]]
        groups = [c["name"] for cid, c in ctx.chats.items() if c["group"] and pid in c["members"]][:4]
        lines = []
        for cid in direct[:1]:
            lines += ctx.snippet(cid, 10)
        if not lines:
            own = [m for m in ctx.msgs if m["sender"] == pid and m["text"]][:4]
            lines = [ctx.line(m) for m in own]
        return "## %s (%s) msgs=%d groups=%s\n%s" % (pid, ctx.label(pid), ctx.senders.get(pid, 0), groups, "\n".join(lines))

    def work(part):
        try:
            res = ctx.llm.chat_json(SYSTEM.format(circles=", ".join(ctx.enums["circle"])), "\n".join(block(p) for p in part), max_tokens=900)
            return {str(r.get("id")): r for r in res.get("people", []) if isinstance(r, dict)}
        except Exception as e:  # LLMError or malformed shape: conservative fallback, never silent
            print("[people] batch failed: %s" % (type(e).__name__ + ": " + str(e)[:150]), file=sys.stderr)
            return {}

    rows = {}
    for d in pmap(work, parts):
        rows.update(d)
    for pid in todo:
        r = rows.get(pid, {})
        circle = clip(r.get("circle"), ctx.enums["circle"])
        conf = r.get("confidence", 0.3) if circle else 0.0
        if not circle or (isinstance(conf, (int, float)) and conf < 0.3):
            circle, conf = "colleague", 0.1
        la = r.get("looks_after")
        la = [str(x) for x in (la if isinstance(la, list) else [la] if la else [])]
        out[pid] = {"id": pid, "name": ctx.label(pid), "circle": circle, "confidence": conf, "source": "llm",
                    "looks_after": [x for x in la if x in known and x != pid] if circle == "staff" else []}
    return list(out.values())
