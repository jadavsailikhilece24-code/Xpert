from collections import Counter, defaultdict

from .preprocessing import fmt, group_by_chat

DEFAULT_ENUMS = {
    "circle": ["spouse", "child", "parent", "in-law", "sibling", "relative", "friend", "colleague", "client",
               "vendor", "partner", "staff"],
    "side": ["home", "work"],
    "otype": ["company", "residence", "vacation home", "workspace", "society", "school", "other"],
    "role": ["owner", "partner", "helper", "resident", "parent", "member", "other"],
    "link": ["runs", "supports"],
    "area": ["self", "spouse", "kids", "parents", "work", "friends", "experiences", "finances", "health", "home"],
    "gtype": ["habit", "milestone", "experience"],
    "horizon": ["3mo", "1yr", "3yr", "5yr"],
    "ltype": ["commitment", "followup", "deadline", "question"],
    "status": ["open", "done", "dropped"],
    "action": ["assist", "remind", "leave"],
}


class Ctx:
    def __init__(self, msgs, chats, seed, self_id, llm, enums=None):
        self.msgs, self.chats, self.seed, self.self_id, self.llm = msgs, chats, seed, self_id, llm
        self.enums = dict(DEFAULT_ENUMS)
        self.enums.update({k: v for k, v in (enums or {}).items() if v})
        self.by_chat = group_by_chat(msgs)
        self.by_id = {m["id"]: m for m in msgs}
        self.names = {}
        cnt = defaultdict(Counter)
        for m in msgs:
            if m["sender_name"]:
                cnt[m["sender"]][m["sender_name"]] += 1
        for s, c in cnt.items():
            self.names[s] = c.most_common(1)[0][0]
        self.senders = Counter(m["sender"] for m in msgs)

    def line(self, m):
        return fmt(m, self.names)

    def label(self, pid):
        return self.names.get(pid) or pid

    def snippet(self, chat_id, n=6, only_self=False):
        ms = [m for m in self.by_chat.get(chat_id, []) if m["text"] and (not only_self or m["sender"] == self.self_id)]
        step = max(1, len(ms) // n)
        return [self.line(m) for m in ms[::step][:n]]


def clip(v, allowed, default=None):
    """Coerce an LLM value to an allowed enum value (case/space-insensitive) or default."""
    if v is None:
        return default
    s = str(v).strip().lower().replace("_", "-")
    for a in allowed:
        if s == str(a).lower().replace("_", "-"):
            return a
    return default
