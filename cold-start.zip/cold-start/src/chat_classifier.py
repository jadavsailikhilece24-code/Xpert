"""Chat -> owner (person or organisation). 1:1 chats are deterministic; groups use the LLM with member/topic context."""
from .util import LEAN, pmap
SYSTEM = """TASK:chats. Map each WhatsApp group to its owner: one organisation id or one person id from the lists. Judge by members, member circles
and message topics (names help but are not enough). Groups almost always belong to an organisation: a company's team, customer/partner/community
groups run by that company, its vendors and operations groups belong to that company; family-home, staff, carpool and household groups belong to the
home;household-staff, carpool and home-logistics groups belong to the home (but wide family/friends/social groups do NOT);
# a society/school/farmhouse group to that place. Use a person only when the group is clearly about one individual (e.g. a child's class parents'
# group belongs to the child). Prefer an organisation whose people appear among the members. Reply JSON only:
{{"chats":[{{"chat_id":"","owner_type":"person|org","owner_id":""}}]}}"""


def run(ctx, people, orgs, links=None, batch=12 * LEAN):
    circle = {p["id"]: p["circle"] for p in people}
    pids = {p["id"] for p in people}
    oids = {o["id"] for o in orgs}
    out, groups = {}, []
    for cid, c in ctx.chats.items():
        others = [m for m in c["members"] if m != ctx.self_id]
        if not c["group"] and len(others) == 1 and others[0] in pids:
            out[cid] = {"chat_id": cid, "owner_type": "person", "owner_id": others[0]}
        elif cid in ctx.by_chat or c["group"]:
            groups.append(cid)
    olinks = {}
    for l in links or []:
        olinks.setdefault(l["org_id"], []).append(l["person_id"])
    head = "ORGS:\n%s\nPEOPLE:\n%s\n" % ("\n".join("%s %s (%s) %s people=%s" % (o["id"], o["name"], o["side"], o["type"], olinks.get(o["id"], [])[:8]) for o in orgs),
                                       "\n".join("%s %s %s" % (p["id"], p["name"], p["circle"]) for p in people))
    def work(part):
        blocks = []
        for cid in part:
            c = ctx.chats[cid]
            blocks.append("## %s '%s' members=%s\n%s" % (cid, c["name"], ["%s(%s)" % (m, circle.get(m, "?")) for m in c["members"] if m != ctx.self_id][:10],
                                                          "\n".join(ctx.snippet(cid, 5))))
        try:
            res = ctx.llm.chat_json(SYSTEM, head[:12000] + "\n".join(blocks), max_tokens=900)
            return res.get("chats", []) if isinstance(res, dict) else []
        except Exception as e:
            import sys
            print("[chats] batch failed: %s" % (type(e).__name__ + ": " + str(e)[:150]), file=sys.stderr)
            return []

    for rows in pmap(work, [groups[i:i + batch] for i in range(0, len(groups), batch)]):
        for r in rows:
            if not isinstance(r, dict):
                continue
            cid, t, oid = str(r.get("chat_id")), r.get("owner_type"), str(r.get("owner_id"))
            if cid in ctx.chats and ((t == "org" and oid in oids) or (t == "person" and oid in pids)):
                out[cid] = {"chat_id": cid, "owner_type": t, "owner_id": oid}
    return [out[c] for c in ctx.chats if c in out]
