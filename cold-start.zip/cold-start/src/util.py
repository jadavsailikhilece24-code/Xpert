import os

# XPERT_LEAN=1 -> about half as many, larger calls (for strict free-tier request limits)
LEAN = 2 if os.environ.get("XPERT_LEAN", "0") == "1" else 1
from concurrent.futures import ThreadPoolExecutor


def pmap(fn, items, workers=None):
    """Ordered parallel map for LLM calls (the 30-minute limit needs concurrency). Workers: XPERT_WORKERS, default 8."""
    items = list(items)
    workers = workers or int(os.environ.get("XPERT_WORKERS", "8"))
    if workers <= 1 or len(items) <= 1:
        return [fn(i) for i in items]
    with ThreadPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(fn, items))
