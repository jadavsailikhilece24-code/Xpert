
import os
import sys
import json
import urllib.request
import urllib.error

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.config import Config, load_dotenv

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(root, ".env"))
cfg = Config.from_env()

url = cfg.base_url.rstrip("/") + "/chat/completions"

payload = {
    "model": cfg.model,
    "messages": [
        {"role": "user", "content": "Reply with hello"}
    ],
    "max_tokens": 30
}

req = urllib.request.Request(
    url,
    data=json.dumps(payload).encode("utf-8"),
    headers={
        "Content-Type": "application/json",
        "Authorization": "Bearer " + cfg.api_key,
        "User-Agent": "cold-start-test/1.0"
    }
)

try:
    with urllib.request.urlopen(req, timeout=30) as response:
        print("SUCCESS:", response.status)
        print(response.read().decode("utf-8")[:1000])
except urllib.error.HTTPError as e:
    print("HTTP ERROR:", e.code)
    print(e.read().decode("utf-8", "replace")[:1500])
except Exception as e:
    print("ERROR:", repr(e))
