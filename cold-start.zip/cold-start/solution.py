#!/usr/bin/env python3
"""Entry point kept compatible with the starter kit:  python3 solution.py <input_dir> <output.json>
(run.sh calls this). The implementation lives in src/."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.main import main  # noqa: E402

if __name__ == "__main__":
    sys.exit(main(["solution.py"] + sys.argv[1:]))
