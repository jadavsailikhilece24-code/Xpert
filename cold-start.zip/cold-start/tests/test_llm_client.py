import tempfile
import unittest
import urllib.error
from unittest import mock

from src.config import Config
from src.llm_client import LLMClient, LLMError, extract_json


def make_client(tmp):
    cfg = Config(base_url="http://x", api_key="k", model="m", max_retries=2,
                 price_in_per_m=1.0, price_out_per_m=2.0, cache_dir=tmp)
    return LLMClient(cfg)


class T(unittest.TestCase):
    def test_extract_json_variants(self):
        self.assertEqual(extract_json('```json\n{"a":1}\n```'), {"a": 1})
        self.assertEqual(extract_json('Sure! {"a":[1,2,],} thanks'), {"a": [1, 2]})
        with self.assertRaises(ValueError):
            extract_json("no json here")

    @mock.patch("time.sleep", lambda s: None)
    def test_retry_repair_usage_cache(self):
        with tempfile.TemporaryDirectory() as tmp:
            c = make_client(tmp)
            replies = iter([
                urllib.error.URLError("boom"),
                {"choices": [{"message": {"content": "not json"}}],
                 "usage": {"prompt_tokens": 10, "completion_tokens": 5}},
                {"choices": [{"message": {"content": '{"ok": true}'}}],
                 "usage": {"prompt_tokens": 12, "completion_tokens": 3}}])

            def fake_post(payload):
                r = next(replies)
                if isinstance(r, Exception):
                    raise r
                return r
            c._post = fake_post
            self.assertEqual(c.chat_json("s", "u"), {"ok": True})
            u = c.usage(n_messages=1000)
            self.assertEqual((u["api_calls"], u["input_tokens"], u["errors"]), (2, 22, 1))
            self.assertAlmostEqual(u["estimated_cost_usd"], (22 * 1 + 8 * 2) / 1e6)
            self.assertEqual(c.chat_json("s", "u"), {"ok": True})
            self.assertEqual(c.cache_hits, 1)

    @mock.patch("time.sleep", lambda s: None)
    def test_gives_up(self):
        with tempfile.TemporaryDirectory() as tmp:
            c = make_client(tmp)
            def down(p): raise urllib.error.URLError("down")
            c._post = down
            with self.assertRaises(LLMError):
                c.chat_json("s", "u")

    def test_mock_mode(self):
        c = LLMClient(Config(mock=True), mock_responder=lambda s, u: {"echo": u})
        self.assertEqual(c.chat_json("s", "hi"), {"echo": "hi"})


if __name__ == "__main__":
    unittest.main()


class HttpPath(unittest.TestCase):
    """Real HTTP round-trip against a local fake OpenAI-compatible server (path, auth header, usage, 400 fallback)."""
    def test_http(self):
        import http.server, json, threading
        seen = {}

        class H(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
                seen.update(path=self.path, auth=self.headers.get("Authorization"), body=body)
                if "response_format" in body and not seen.get("rejected"):
                    seen["rejected"] = True
                    self.send_response(400); self.end_headers(); self.wfile.write(b"{}"); return
                out = json.dumps({"choices": [{"message": {"content": '{"ok": true}'}}], "usage": {"prompt_tokens": 7, "completion_tokens": 2}}).encode()
                self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(out)
            def log_message(self, *a): pass

        srv = http.server.HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        with tempfile.TemporaryDirectory() as tmp:
            cfg = Config(base_url="http://127.0.0.1:%d/v1beta/openai" % srv.server_port, api_key="k123", model="m", cache_dir=tmp)
            c = LLMClient(cfg)
            self.assertEqual(c.chat_json("s", "u"), {"ok": True})
        srv.shutdown()
        self.assertEqual(seen["path"], "/v1beta/openai/chat/completions")
        self.assertEqual(seen["auth"], "Bearer k123")
        self.assertEqual(c.usage()["input_tokens"], 7)


class RateLimit(unittest.TestCase):
    def _client(self, tmp):
        return LLMClient(Config(base_url="http://x", api_key="k", model="m", max_retries=3, cache_dir=tmp))

    @mock.patch("time.sleep")
    def test_429_honours_server_delay_and_recovers(self, sleep):
        import io
        with tempfile.TemporaryDirectory() as tmp:
            c = self._client(tmp)
            replies = iter([urllib.error.HTTPError("u", 429, "x", {}, io.BytesIO(b'{"error":"Please retry in 12.5s"}')),
                            {"choices": [{"message": {"content": '{"ok": 1}'}}], "usage": {}}])
            def post(p):
                r = next(replies)
                if isinstance(r, Exception): raise r
                return r
            c._post = post
            self.assertEqual(c.chat_json("TASK:x s", "u"), {"ok": 1})
            self.assertTrue(any(abs(call.args[0] - 13.5) < 0.01 for call in sleep.call_args_list), sleep.call_args_list)

    def test_daily_quota_fails_fast_and_disables(self):
        import io
        with tempfile.TemporaryDirectory() as tmp:
            c = self._client(tmp)
            def post(p):
                raise urllib.error.HTTPError("u", 429, "x", {}, io.BytesIO(b'{"error":"Quota exceeded ... GenerateRequestsPerDayPerProjectPerModel limit: 0"}'))
            c._post = post
            with self.assertRaises(LLMError) as cm:
                c.chat_json("TASK:x s", "u")
            self.assertIn("quota", str(cm.exception).lower())
            self.assertTrue(c.disabled)
            with self.assertRaises(LLMError):
                c.chat_json("TASK:x s", "u2")   # no further calls once disabled

    @mock.patch("time.sleep", lambda s: None)
    def test_circuit_breaker(self):
        with tempfile.TemporaryDirectory() as tmp:
            c = self._client(tmp)
            c._post = lambda p: (_ for _ in ()).throw(urllib.error.URLError("down"))
            for i in range(35):
                with self.assertRaises(LLMError):
                    c.chat_json("TASK:x s", "u%d" % i)
            self.assertTrue(c.disabled)
