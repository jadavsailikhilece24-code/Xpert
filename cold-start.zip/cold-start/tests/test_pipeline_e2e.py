"""End-to-end plumbing test on SYNTHETIC data with a SYNTHETIC schema (not the official Xpert files) in mock-LLM mode."""
import json
import os
import tempfile
import unittest

from src import main as xmain
from src.schema_utils import validate
from tests.mock_llm import responder

SCHEMA = {"type": "object", "required": ["people", "organisations", "chats", "goals", "open_loops"], "properties": {
    "people": {"type": "array", "items": {"type": "object", "required": ["id", "circle"], "properties": {
        "id": {"type": "string"}, "name": {"type": "string"}, "circle": {"enum": ["friend", "staff", "colleague"]}}}},
    "organisations": {"type": "array", "items": {"type": "object", "properties": {
        "id": {"type": "string"}, "name": {"type": "string"}, "side": {"enum": ["home", "work"]}}}},
    "chats": {"type": "array", "items": {"type": "object", "properties": {
        "chat_id": {"type": "string"}, "owner_id": {"type": "string"}}}},
    "goals": {"type": "array", "maxItems": 10, "items": {"type": "object", "properties": {
        "description": {"type": "string"}, "area": {"enum": ["health", "work"]}, "horizon": {"enum": ["1yr", "3yr"]},
        "evidence": {"type": "array", "items": {"type": "string"}}}}},
    "open_loops": {"type": "array", "items": {"type": "object", "required": ["title", "status"], "properties": {
        "title": {"type": "string"}, "status": {"enum": ["open", "done", "dropped"]},
        "action": {"enum": ["assist", "remind", "leave"]}}}}}}


def jl(path, rows):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")


class E2E(unittest.TestCase):
    def test_pipeline(self):
        with tempfile.TemporaryDirectory() as d:
            ind = os.path.join(d, "in"); os.makedirs(ind)
            jl(os.path.join(ind, "chats.jsonl"), [{"id": "c1", "name": "Ravi", "is_group": False},
                                                   {"id": "c2", "name": "Team", "is_group": True}])
            t = lambda i: "2026-01-0%dT10:00:00Z" % i
            M = lambda i, c, s, tx, ts, **k: dict(id=i, chat_id=c, sender_id=s, sender_name={"me": "Arjun", "u_ravi": "Ravi"}.get(s, s), text=tx, timestamp=ts, **k)
            jl(os.path.join(ind, "messages.jsonl"), [
                M("m1", "c1", "me", "I will send the invoice tomorrow to you", t(1)),
                M("m2", "c1", "u_ravi", "ok great thanks a lot", t(1)),
                M("m3", "c1", "u_ravi", "driver will come at 9 for pickup", t(2)),
                M("m4", "c1", "me", "Invoice sent, please check the mail", t(3), quoted_id="m1"),
                M("m5", "c1", "u_ravi", "received, thanks a lot Arjun", t(3)),
                M("m6", "c2", "me", "Let's aim to run a half marathon this year, training starts now", t(2)),
                M("m6b", "c2", "u_x", "nice plan Arjun you can do it", t(2)),
                M("m6c", "c2", "me", "please send the invoice for March to accounts team", t(4)),
                M("m6d", "c2", "u_x", "noted, will check", t(4)),
                M("m1d", "c1", "me", "bhai kal milte hain office pe", t(4)),
            ])
            os.environ["LLM_MOCK"] = "1"
            os.environ["XPERT_SCHEMA"] = os.path.join(d, "schema.json")
            with open(os.environ["XPERT_SCHEMA"], "w", encoding="utf-8") as f:
                json.dump(SCHEMA, f)
            out = os.path.join(d, "out", "o.json")
            rc = xmain.run(ind, out, mock_responder=responder)
            with open(out, encoding="utf-8") as f:
                data = json.load(f)
            self.assertEqual(rc, 0, "validation problems reported")
            self.assertEqual(validate(SCHEMA, data), [])
            loops = {l["title"]: l for l in data["open_loops"]}
            self.assertNotIn("Fake loop", loops)            # unverifiable origin id rejected
            self.assertTrue(any(l["status"] == "done" for l in data["open_loops"]))  # tracked to completion
            self.assertTrue(any(l["status"] == "open" and l.get("help", {}).get("action") == "remind" for l in data["open_loops"]))
            self.assertEqual(len(data["goals"]), 1)
            self.assertEqual({p["id"] for p in data["people"]}, {"u_ravi", "u_x"})
            os.environ.pop("LLM_MOCK"); os.environ.pop("XPERT_SCHEMA")


if __name__ == "__main__":
    unittest.main()
