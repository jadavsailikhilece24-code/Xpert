"""Deterministic stand-in for the LLM, for plumbing tests ONLY. It proves the pipeline, validation and cost plumbing work;
it says nothing about real model quality."""
import re


def responder(system, user):
    task = system.split()[0]
    ids = re.findall(r"^\[(\w+)\]", user, re.M)
    if task == "TASK:people.":
        out = []
        for m in re.finditer(r"^## (\S+) \(", user, re.M):
            pid = m.group(1)
            out.append({"id": pid, "circle": "staff" if "driver" in user.lower() and pid == "u_ravi" else "friend", "confidence": 0.8})
        return {"people": out}
    if task == "TASK:orgs.":
        return {"orgs": [{"key": "o1", "name": "Sharma Textiles", "type": "company", "side": "work", "role": "owner"}],
                "links": [{"person_id": "u_ravi", "org": "o1", "link": "supports"}]}
    if task == "TASK:chats.":
        return {"chats": [{"chat_id": c, "owner_type": "org", "owner_id": "org_1"} for c in re.findall(r"^## (\S+) '", user, re.M)]}
    if task == "TASK:goal_candidates.":
        return {"goals": [{"text": "Run a half marathon", "area": "health", "type": "milestone", "horizon": "1yr", "evidence": ids[:1]}]
                if any("marathon" in l for l in user.splitlines()) else []}
    if task == "TASK:goal_merge.":
        return {"goals": [{"text": "Run a half marathon", "area": "health", "type": "milestone", "horizon": "1yr",
                           "evidence": re.findall(r"'(m\d\w*)'", user)[:1]}]}
    if task == "TASK:loops.":
        rows = []
        for line in user.splitlines():
            if "send the invoice" in line.lower():
                mid = re.match(r"\[(\w+)\]", line).group(1)
                rows.append({"title": "Send invoice", "type": "commitment", "owner": "self", "message_id": mid, "due": None})
        if rows:
            rows.append({"title": "Fake loop", "type": "question", "owner": "self", "message_id": "nope", "due": None})
        return {"loops": rows}
    if task == "TASK:track.":
        lid = re.search(r"^(loop_\d+):", user, re.M).group(1)
        done = [m for m in re.findall(r"^\[(\w+)\].*invoice sent", user, re.M | re.I)]
        return {"loops": [{"id": lid, "status": "done", "evidence": done[0]}] if done else [{"id": lid, "status": "open", "evidence": None}]}
    if task == "TASK:assist.":
        return {"decisions": [{"id": i, "action": "remind", "remind_at": "2026-01-10T09:00:00", "reason": "Only Arjun can do it"}
                              for i in re.findall(r"^(loop_\d+):", user, re.M)]}
    return {}
