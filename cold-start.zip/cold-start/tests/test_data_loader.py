import os
import tempfile
import unittest

from src.data_loader import profile, read_jsonl


class T(unittest.TestCase):
    def test_bad_lines_and_duplicates(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "m.jsonl")
            with open(p, "w", encoding="utf-8") as f:
                f.write('{"id":1,"a":1}\nnot json\n{"id":1}\n{"x":2}\n[1]\n{"id":2}\n')
            recs, probs = read_jsonl(p, id_field="id")
            self.assertEqual([r["id"] for r in recs], [1, 2])
            self.assertEqual(len(probs), 4)
            self.assertEqual(profile(recs)["count"], 2)

    def test_missing_and_empty(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(FileNotFoundError):
                read_jsonl(os.path.join(d, "nope.jsonl"))
            p = os.path.join(d, "e.jsonl")
            open(p, "w").close()
            recs, probs = read_jsonl(p)
            self.assertEqual(recs, [])
            self.assertTrue(probs)


if __name__ == "__main__":
    unittest.main()
